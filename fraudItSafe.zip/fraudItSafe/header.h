#include <gtk/gtk.h>
#include <winsock.h>
#include <MYSQL\mysql.h>

void insertInStationList(GtkBuilder *builder);
void giveAlert(GtkBuilder *builder);
void printAlertByLine(GtkBuilder *builder);
