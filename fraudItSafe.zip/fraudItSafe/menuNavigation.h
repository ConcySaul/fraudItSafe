#include <gtk/gtk.h>

void backToMenuEvent(GtkBuilder *builder);
void changePageToAlert(GtkBuilder *builder);
void changePageToPrintAlert(GtkBuilder *builder);
void changePageToAllAlerts(GtkBuilder *builder);
void changePageToLineToFraud(GtkBuilder *builder);
void changePageToStationToFraud(GtkBuilder *builder);

